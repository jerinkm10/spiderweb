<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <?php echo $__env->make('flash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>            
        </div>
    </div>
    <div class="container">
        <div class="row">      
            <div class="col-md-6"> 
                <h2>Assignment Lists</h2>
            </div>               
                
        </div>

        <hr>
        <div class="row">
            <div class="col-md-12">
              <table summary="This is table" class="table table-bordered table-hover dt-responsive" style="width: 100%">
              
                
                <thead>
                      <tr>
                        <th>Student Name</th>
                        <th>Teacher Name</th>
                        <th>Subject Name</th>
                        <th>Assignment Title</th>
                        <th>Status</th>
                        <th><span class="fa fa-ellipsis-h"></span></th>
                      </tr>
                </thead>
                <tbody>
                    <?php if($assignments): ?>
                    <?php $__currentLoopData = $assignments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $assignment): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <?php $subject = \App\Subject::findOrFail($assignment->subject_id); 
                    $teacher = \App\Teacher::findOrFail($subject->teacher_id); 
                    $student = \App\Student::findOrFail($assignment->student_id); ?>
                    <tr>
                        <td><?php echo e(ucwords($student->name)); ?></td>
                        <td><?php echo e(ucwords($teacher->name)); ?></td>
                        <td><?php echo e(ucwords($subject->name)); ?></td>
                        <td><?php echo e($assignment->name); ?></td>
                        <td>
                            <?php if($assignment->status == 1): ?>
                                <span class="btn btn-success">Approved</span>
                            <?php else: ?>
                                <span class="btn btn-danger">Pending</span>
                            <?php endif; ?>
                        </td>
                        
                        <td>
                            
                            <a type="button" class="btn btn-primary btn-md" href="<?php echo e(route('admin.assignments.edit', $assignment->id)); ?>"><i class="fa fa-pencil"></i></a>
                            <a type="button" class="btn btn-danger btn-md" href="<?php echo e(route('admin.assignments.delete', $assignment->id)); ?>" onclick="return confirm('Are you sure')"><i class="fa fa-trash"></i></a>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>                 
                </tbody>
              </table>
            </div>
        </div>
    </div>
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\simple-school\resources\views/admins/list_assignment.blade.php ENDPATH**/ ?>