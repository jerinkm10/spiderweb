  <div class="bg-light border-right" id="sidebar-wrapper">
      <div class="sidebar-heading">  
        <a class="navbar-brand" href="<?php echo e(url('/')); ?>">
            <?php echo e(config('app.name', 'Laravel')); ?>

        </a> 
      </div>
      <div class="list-group list-group-flush">
        <a href="<?php echo e(url('/')); ?>" class="list-group-item list-group-item-action bg-light">Dashboard</a>
        <?php if(Auth::user()->isAdmin()): ?>
        <a href="<?php echo e(route('admin.teachers.index')); ?>" class="list-group-item list-group-item-action bg-light">Teachers</a>
        <a href="<?php echo e(route('admin.students.index')); ?>" class="list-group-item list-group-item-action bg-light">Students</a>
        <a href="<?php echo e(route('admin.subjects.index')); ?>" class="list-group-item list-group-item-action bg-light">Subjects</a>
        <a href="<?php echo e(route('admin.assignments.index')); ?>" class="list-group-item list-group-item-action bg-light">Assignments</a>
        <?php endif; ?>
        <?php if(Auth::user()->isTeacher()): ?>
        <a href="<?php echo e(route('teacher.assignments.index')); ?>" class="list-group-item list-group-item-action bg-light">Assignments</a>
        <?php endif; ?>
        <?php if(Auth::user()->isStudent()): ?>
        <a href="<?php echo e(route('student.assignments.index')); ?>" class="list-group-item list-group-item-action bg-light">Assignments</a>
        <?php endif; ?>
        <?php if(Auth::user()->isAdmin()): ?>
        <a href="<?php echo e(route('admin.meetings.index')); ?>" class="list-group-item list-group-item-action bg-light">Live Class</a>
        <?php endif; ?> 
        <?php if(Auth::user()->isTeacher()): ?>
        <a href="<?php echo e(route('teacher.meetings.index')); ?>" class="list-group-item list-group-item-action bg-light">Live Class</a>
        <?php endif; ?>
        <?php if(Auth::user()->isStudent()): ?>
        <a href="<?php echo e(route('student.meetings.index')); ?>" class="list-group-item list-group-item-action bg-light">Live Class</a>
        <?php endif; ?>
      </div>
    </div>
<?php /**PATH D:\xampp\htdocs\simple-school\resources\views/partials/sidebar.blade.php ENDPATH**/ ?>