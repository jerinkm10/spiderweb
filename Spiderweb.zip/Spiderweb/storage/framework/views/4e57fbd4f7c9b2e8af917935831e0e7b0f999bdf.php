<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <?php echo $__env->make('flash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>            
        </div>
    </div>
    <div class="container">
        <div class="row">      
            <div class="col-md-6"> 
                <h2>Teacher Lists</h2>
            </div>               
            <div class="col-md-6">                
                <a href="<?php echo e(route('admin.teachers.create')); ?>" class="btn btn-primary pull-right"><span class="fa fa-plus"></span> Add Teacher</a>
            </div>    
        </div>

        <hr>
        <div class="row">
            <div class="col-md-12">
              <table summary="This is table" class="table table-bordered table-hover dt-responsive" style="width: 100%">
              
                
                <thead>
                      <tr>
                        <th>Name</th>
                        <th>DOB</th>
                        <th>Gender</th>
                        <th>Phone</th>
                        <th>Specialization</th>
                        <th><span class="fa fa-ellipsis-h"></span></th>
                      </tr>
                </thead>
                <tbody>
                    <?php if($teachers): ?>
                    <?php $__currentLoopData = $teachers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $teacher): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e(ucwords($teacher->name)); ?></td>
                        <td><?php echo e($teacher->dob); ?></td>
                        <td><?php if($teacher->gender == 1): ?> Male <?php elseif($teacher->gender == 2): ?> Female  <?php endif; ?></td>
                        <td><?php echo e($teacher->phone_no); ?></td>
                        <td><?php echo e(ucwords($teacher->specialization)); ?></td>
                        <td>
                            
                            <a type="button" class="btn btn-primary btn-md" href="<?php echo e(route('admin.teachers.edit', $teacher->id)); ?>"><i class="fa fa-pencil"></i></a>
                            <a type="button" class="btn btn-danger btn-md" href="<?php echo e(route('admin.teachers.delete', $teacher->id)); ?>" onclick="return confirm('Are you sure')"><i class="fa fa-trash"></i></a>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>                 
                </tbody>
              </table>
            </div>
        </div>
    </div>
    
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\simple-school\resources\views/admins/list_teacher.blade.php ENDPATH**/ ?>