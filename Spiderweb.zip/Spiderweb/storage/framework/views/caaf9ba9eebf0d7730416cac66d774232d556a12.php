<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-10">
                <?php echo $__env->make('flash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>            
        </div>
    </div>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-10">
                <div class="card">
                    <div class="card-header">Update Assignment</div>

                    <div class="card-body">
                        <form method="POST" action="<?php echo e(route('teacher.assignments.update')); ?>" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="id" value="<?php echo e($assignment->student_id); ?>">
                            
                            <div class="form-group row">
                                <label for="feedback" class="col-md-4 col-form-label text-md-right"><?php echo e(__('Feedback')); ?></label>

                                <div class="col-md-6">
                                    <textarea rows="5" id="feedback" type="text" class="form-control <?php $__errorArgs = ['feedback'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" name="feedback" required autocomplete="feedback" autofocus><?php echo e(old('feedback', $assignment->feedback)); ?></textarea>
                                    <?php $__errorArgs = ['feedback'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($message); ?></strong>
                                        </span>
                                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                </div>
                            </div>

                            <div class="form-group row">
                                <div class="col-md-6 offset-md-4">
                                    <div class="form-check">
                                        <input class="form-check-input" type="checkbox" name="status" id="status" <?php echo e(old('status',$assignment->status == 1) ? 'checked' : ''); ?>>

                                        <label class="form-check-label" for="status">
                                            <?php echo e(__('Status')); ?>

                                        </label>
                                    </div>
                                </div>
                            </div>

                            <div class="form-group row mb-0">
                                <div class="col-md-8 offset-md-4">
                                    <button type="submit" class="btn btn-primary">
                                        <?php echo e(__('SAVE')); ?>

                                    </button>
                                    <button type="reset" class="btn btn-info">
                                        <?php echo e(__('CLEAR')); ?>

                                    </button>                                 
                                    <a class="btn btn-danger" href="<?php echo e(route('student.assignments.index')); ?>">
                                        <?php echo e(__('GO BACK')); ?>

                                    </a>                                
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
    </div>        
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\simple-school\resources\views/teachers/edit_assignment.blade.php ENDPATH**/ ?>