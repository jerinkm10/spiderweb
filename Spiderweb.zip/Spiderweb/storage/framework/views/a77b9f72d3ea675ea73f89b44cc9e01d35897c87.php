<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <?php echo $__env->make('flash', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>            
        </div>
    </div>
    <div class="container">
        <div class="row">      
            <div class="col-md-6"> 
                <h2>Zoom Meeting Lists</h2>
            </div>               
            <div class="col-md-6">                
                <a href="<?php echo e(route('admin.meetings.create')); ?>" class="btn btn-primary pull-right"><span class="fa fa-plus"></span> Add Meeting</a>
            </div>    
        </div>
        
        <hr>
        <div class="row">
            <div class="col-md-12">
              <table summary="This is table" class="table table-bordered table-hover dt-responsive" style="width: 100%">
              
                
                <thead>
                      <tr>
                        <th>Meeting Topic</th>
                        <th>Start Time</th>
                        <th>Agenda</th>
                        <th>Duration</th>
                        <th>Meeting Link</th>
                        <th><span class="fa fa-ellipsis-h"></span></th>
                      </tr>
                </thead>
                <tbody>
                    <?php if($meetings): ?>
                    <?php $__currentLoopData = $meetings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $meeting): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e(ucwords($meeting->topic)); ?></td>
                        <td><?php echo e($meeting->start_time); ?></td>
                        <td><?php echo e(ucwords($meeting->agenda)); ?></td>
                        <td><?php echo e($meeting->duration); ?> Min </td>
                        <td>
                            <a href="<?php echo e($meeting->join_url); ?>" target="_blank" class="btn btn-success">Open Link</a>
                            <a class="btn btn-info copy_text" href="<?php echo e($meeting->join_url); ?>" data-toggle="tooltip" title="Copy to Clipboard" class="btn btn-info">Copy Link</a>                            
                        </td>
                        <td>
                            
                            <a title="End the meeting!!" type="button" class="btn btn-primary btn-md" href="<?php echo e(route('admin.meetings.end', $meeting->id)); ?>"><i class="fa fa-remove"></i></a>     
                            <a type="button" class="btn btn-primary btn-md" href="<?php echo e(route('admin.meetings.edit', $meeting->id)); ?>"><i class="fa fa-pencil"></i></a>
                            <a type="button" class="btn btn-danger btn-md" href="<?php echo e(route('admin.meetings.delete', $meeting->id)); ?>" onclick="return confirm('Are you sure')"><i class="fa fa-trash"></i></a>
                        </td>
                    </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    <?php endif; ?>                 
                </tbody>
              </table>
            </div>
        </div>
    </div>
    
    
  
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\simple-school\resources\views/admins/list_meeting.blade.php ENDPATH**/ ?>