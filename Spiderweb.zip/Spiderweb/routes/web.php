<?php

use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

// By default redirect to appropriate dashboard as per user type.
Route::get('/', function () {
    return Redirect::to('login');
});
// Logout Hook.
Route::get('/logout', function(){
    Auth::logout();
    return Redirect::to('login');
});
// Auth routes.
Auth::routes();

// for handing /home route.
Route::get('/home', function(){
    
    if(Auth::User()->isAdmin()){
        return Redirect::to('/admin');
    } else if(Auth::User()->isTeacher()) {
        return Redirect::to('/teacher');
    } else {
        Auth::logout();
        return Redirect::to('login');
    }

});


// Admin Routes
Route::group(['middleware' => ['auth', 'admin'], 'prefix' => 'admin'], function () {

    Route::get('/', 'AdminController@index')->name('admin');
    // for teacher 
     Route::group(['prefix'  =>   'teachers'], function() {
         Route::get('/', 'AdminController@teacher')->name('admin.teachers.index');
         Route::get('/create', 'AdminController@teacherCreate')->name('admin.teachers.create');
         Route::post('/store', 'AdminController@teacherStore')->name('admin.teachers.store');
         Route::get('/{teacher}/edit', 'AdminController@teacherEdit')->name('admin.teachers.edit');
         Route::post('/update', 'AdminController@teacherUpdate')->name('admin.teachers.update');
         Route::get('/{teacher}/delete', 'AdminController@teacherDelete')->name('admin.teachers.delete');
     });
    
    // for zoom meeting 
    Route::group(['prefix'  =>   'meetings'], function() {
        Route::get('/', 'AdminController@meeting')->name('admin.meetings.index');
        Route::get('/create', 'AdminController@meetingCreate')->name('admin.meetings.create');
        Route::get('/gmail_send', 'AdminController@gmail_send')->name('admin.meetings.gmail_send');
        Route::post('/store', 'AdminController@meetingStore')->name('admin.meetings.store');
        Route::get('/{meeting}/edit', 'AdminController@meetingEdit')->name('admin.meetings.edit');
        Route::post('/update', 'AdminController@meetingUpdate')->name('admin.meetings.update');
        Route::get('/{meeting}/end', 'AdminController@meetingEnd')->name('admin.meetings.end');
        Route::get('/{meeting}/delete', 'AdminController@meetingDelete')->name('admin.meetings.delete');
    });






});

