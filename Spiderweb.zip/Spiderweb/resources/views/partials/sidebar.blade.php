  <div class="bg-light border-right" id="sidebar-wrapper">
      <div class="sidebar-heading">  
        <a class="navbar-brand" href="{{ url('/') }}">
            {{ config('app.name', 'Laravel') }}
        </a> 
      </div>
      <div class="list-group list-group-flush">
        <a href="{{ url('/') }}" class="list-group-item list-group-item-action bg-light">Dashboard</a>
        @if(Auth::user()->isAdmin())
        <a href="{{ route('admin.teachers.index') }}" class="list-group-item list-group-item-action bg-light">listeners</a>
        @endif
        @if(Auth::user()->isAdmin())
        <a href="{{ route('admin.meetings.index') }}" class="list-group-item list-group-item-action bg-light">Live Class</a>
        @endif 
       
      </div>
    </div>
