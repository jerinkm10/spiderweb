<?php

namespace App\Http\Controllers;

use App\Assignment;
use App\Student;
use App\Subject;
use App\Teacher;
use App\User;
use DateTime;
use Mail;
use DB;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Redirect;




class AdminController extends Controller
{
     /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        return view('admins.dashboard');
    }

    /******************************************/
    /************ TEACHER SECTION *************/
    /******************************************/

    public function teacher()
    {
        $teachers = Teacher::all();
        return view('admins.list_teacher', compact('teachers'));
    }

    public function teacherCreate()
    {
        return view('admins.add_teacher');
    }
    public function teacherStore(Request $request)
    {
        
        $this->validate($request, [
            'name'              =>  'required|max:191', // size:191
            'dob'               =>  'required|date',
            'phone_no'          =>  'required|digits_between:10,10|numeric',
            'gender'            =>  'required|integer',
            'email'             =>  'required|unique:users|unique:teachers',
            'address'           =>  'required|string|max:55',
            'specialization'    =>  'required|string',
            'photo'             =>  'image|mimes:jpeg,png,jpg,gif,svg|max:2048',
            'password'          =>  'required|string|min:8|confirmed',
        ]);

        if ($file = $request->file('photo')) {
           $destinationPath = 'public/photos/'; // upload path
           $profileImage = date('YmdHis') . "." . $file->getClientOriginalExtension();
           $file->move($destinationPath, $profileImage);
        }

        // for user  data.
        $user_data = array(
            'name'      => $request->name,
            'email'     => $request->email,
            'role'      => 'teacher',
            'password'  => Hash::make($request->password)
        );
        
        // first insert data into user table.       
        $user_insert = User::create($user_data); 

        // for teacher data.
        $teacher_data = [
            'user_id'           =>  ($user_insert->id)?$user_insert->id:0,
            'name'              =>  $request->name,
            'dob'               =>  $request->dob,
            'email'             =>  $request->email,
            'phone_no'          =>  $request->phone_no,
            'gender'            =>  $request->gender,
            'address'           =>  $request->address,
            'specialization'    =>  $request->specialization,
            'photo'             =>  ($profileImage)?$profileImage:NULL
        ];

        // second insert teacher with user id.
        $user_teacher_insert = Teacher::create($teacher_data); 

        if($user_teacher_insert && $user_insert){
            return redirect()->route("admin.teachers.index")
                ->withSuccess('Great! listeners has been successfully added.');
        } else {            
            return redirect()->back()
                ->withErrors('error','listeners couldn\'t added.');
        }
    }
    public function teacherEdit(Teacher $teacher)
    {
        return view('admins.edit_teacher', compact('teacher'));
    }

    public function teacherUpdate(Request $request)
    {
        // dd($request->all());

        $this->validate($request, [
            'name'              =>  'required|max:191', // size:191
            'dob'               =>  'required|date',
            'phone_no'          =>  'required|digits_between:10,10|numeric',
            'gender'            =>  'required|integer',
            'email'             =>  'unique:users|unique:teachers',
            'address'           =>  'required|string|max:55',
            'specialization'    =>  'required|string',
            'photo'             =>  'image|mimes:jpeg,png,jpg,gif,svg|max:2048',
            'password'          =>  'nullable|string|min:8',
        ]);
        // get teacher data.
        $teacher = Teacher::findOrFail($request->id);
        // teacher photo update.
        $profileImage  = '';
        if ($file = $request->file('photo')) {
           $destinationPath = 'public/photos/'; // upload path
           $profileImage = date('YmdHis') . "." . $file->getClientOriginalExtension();
           $file->move($destinationPath, $profileImage);
        }
        // for user  data.
        $user_data = array(
            'name'      => $request->name
        );
        // for password
        if(!is_null($request->password)){
            $user_data['password'] = Hash::make($request->password); //bcrypt
        }
        // for email.            
        if(!is_null($request->email)){
            $user_data['email'] = $request->email;
        }
        // first insert data into user table.       
        $user_update = User::where('id', $request->user_id)->update($user_data); 

        // for teacher data.
        $teacher_data = [
            'name'              =>  $request->name,
            'dob'               =>  $request->dob,
            'email'             =>  ($request->email)?$request->email:$teacher->email,
            'phone_no'          =>  $request->phone_no,
            'gender'            =>  $request->gender,
            'address'           =>  $request->address,
            'specialization'    =>  $request->specialization,
            'photo'             =>  ($profileImage)?$profileImage:$teacher->photo
        ];

        // second insert teacher with user id.
        $user_teacher_udpate = Teacher::where('id', $request->id)->update($teacher_data); 

        if($user_teacher_udpate && $user_update){
            return redirect()->route("admin.teachers.index")
                ->withSuccess('Great! listeners has been successfully updated.');
        } else {            
            return redirect()->back()
                ->withErrors('error','listeners couldn\'t update.');
        }
    }

    public function teacherDelete($id)
    {       
        $teacher = Teacher::findOrFail($id);
        $user_teacher = User::findOrFail($teacher->user_id);
        if($teacher->delete() && $user_teacher->delete()){
            return redirect()->route('admin.teachers.index')->with('success','listeners deleted successfully.');
        } else {
            return redirect()->back()->with('error',' listeners couldn\'t delete, please try again.');
        }
    }


    /******************************************/
    /************ MEETING SECTION *************/
    /******************************************/

    public function meeting()
    {

        // $zoom = new \MacsiDigital\Zoom\Support\Entry;
        // $user = new \MacsiDigital\Zoom\User($zoom);
        // dd($user);

        $user = \Zoom::user()->find('me');
        $meetings = $user->meetings()->get();
        // dd($meetings);

        // $meetings = LiveStream::all();
        return view('admins.list_meeting', compact('meetings'));
    }

    public function meetingCreate()
    {
        return view('admins.add_meeting');
    }
    public function meetingStore(Request $request)
    {
         
        $this->validate($request, [
            'name'              =>  'required|max:191', 
            'agenda'            =>  'required|string|max:2000',
            'duration'          =>  'numeric|max:120',
            'password'          =>  'nullable|string|min:8',
        ]);
        // dd(str_replace( 'T', '', $request->start_time ));
        // $month ='04';
        // $year ='2022';
        // $date = new DateTime("first monday of $year-$month");
        // $thisMonth = '04';

        //     while ($date->format('m') === $thisMonth) {
               // echo , "\n";
               $dateses =date('m', strtotime($request->start_time ));
               $time =date('H:i:s', strtotime($request->start_time ));
               //dd();
               $month = $dateses;
               
                $year ='2022';
                $number_of_days = cal_days_in_month(CAL_GREGORIAN, $dateses, $year);
                for ($x = 1; $x <= $number_of_days; $x++) {
                    if( date("l", strtotime($x . "-" . $month . "-" . $year)) == 'Monday' or date("l", strtotime($x . "-" . $month . "-" . $year)) == 'Tuesday' or date("l", strtotime($x . "-" . $month . "-" . $year)) == 'Wednesday' or date("l", strtotime($x . "-" . $month . "-" . $year)) == 'Thursday'){
                        $dateses = $x . "-" . $month . "-" . $year;
                        $dates = date("Y-m-d H:i:s", strtotime($dateses . $time));
 
                
                $data =  [
                    'topic' => $request->name,
                    'agenda' => $request->agenda,
                    'type' => 2,
                    //'start_time' => date('Y-m-d H:i:s', strtotime($request->start_time )),
                    'start_time' => $dates,
                    'timezone' => 'Asia/Calcutta',
                    'duration' => $request->duration,
                    'password' => $request->password,
                    'settings' => [
                        'join_before_host'  =>  false,
                        'host_video'        =>  false,
                        'participant_video' => false,
                        'mute_upon_entry'   => false,
                        'enforce_login'     => false,
                        'auto_recording'    => "none",
                        'alternative_hosts' => ""
                    ]
                ];
        
                
                
                $user = \Zoom::user()->find('me');
                $user->meetings()->create($data);
               
        }
     }
    
                            return redirect()->route("admin.meetings.index")  ->withSuccess('Great! Meeting has been successfully added.');
    }
    public function gmail_send()
    {
        $data = DB::table('teachers')
        ->select('*')
        ->get();
        $user = \Zoom::user()->find('me');
        $meetings = $user->meetings()->get();
         foreach($data as $value){
            //echo $value->email;
            $cc_to = 'jerinkm10@gmail.com';
            $email = $value->email;
            $user = \Zoom::user()->find('me');
        $meetings = $user->meetings()->get();
        //dd($meetings);
        $mail_url ="";
        foreach($meetings as $meeting){
         //   echo $meeting->join_url;
            $mail_url = $meeting->join_url;
           // echo $mail_url;
            $mailMsg = "Dear sir, \n   \n Message = \n ".$mail_url." \n Regards,\n ";
                                  
            
            Mail::raw($mailMsg, function ($message) use ($email, $cc_to) {
                $message->from('jerinkm1010@gmail.com', 'demo A zoom');
                $message->to($email)->subject('ZOOM LINK : password: 12345678');
                
            });} }

            
   
           
         if (Mail::failures()) {
            //return view("book-a-demo");
        }else{
            return redirect()->route("admin.meetings.index")  ->withSuccess('Great! Mail has been successfully SENDED.');
        }
        //return view('admins.edit_meeting', compact('meeting'));
    }
    public function meetingEdit($meeting_id)
    {
        $meeting =  \Zoom::meeting()->find($meeting_id);
        return view('admins.edit_meeting', compact('meeting'));
    }

    public function meetingEnd($id)
    {       
        $meeting = \Zoom::meeting()->find($id);
        dd($meeting);
        if($meeting->endMeeting()){
            return redirect()->route('admin.meetings.index')->with('success','Meeting ended successfully.');
        } else {
            return redirect()->back()->with('error',' Meeting couldn\'t end, please try again.');
        }
    }
    public function meetingDelete($id)
    {       
        $meeting = \Zoom::meeting()->find($id);
        if($meeting->delete()){
            return redirect()->route('admin.meetings.index')->with('success','Meeting deleted successfully.');
        } else {
            return redirect()->back()->with('error',' Meeting couldn\'t delete, please try again.');
        }
    }
    
}
